//
//  webServiceManager.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import UIKit
import Foundation
class webServiceManager{
    static let shared = webServiceManager()
    var session:URLSession = URLSession.shared
    
    private init(){}
    
    func parseMovieList(jsonData:Data,completion:@escaping(([Movie]) -> ())){
       var movieArr = [Movie]()
        do {
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let newsDict  = try decoder.decode(MovieList.self, from: jsonData)
            
            let updatedArticles = newsDict.Search 
            movieArr   = updatedArticles
            
            
        } catch DecodingError.dataCorrupted(let context) {
            print(context)
        } catch DecodingError.keyNotFound(let key, let context) {
            print("Key '\(key)' not found:", context.debugDescription)
            print("codingPath:", context.codingPath)
        } catch DecodingError.valueNotFound(let value, let context) {
            print("Value '\(value)' not found:", context.debugDescription)
            print("codingPath:", context.codingPath)
        } catch DecodingError.typeMismatch(let type, let context) {
            print("Type '\(type)' mismatch:", context.debugDescription)
            print("codingPath:", context.codingPath)
        } catch {
            print("error: ", error)
        }
        completion(movieArr )
        
        
    }
    
    
    func  makeRequestMovieList(urlStr:String,completion :@escaping ([Movie]) -> ()){
        
        let urlString = urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        
        guard let finalUrlString = urlString  else {return }
        let url = URL(string: finalUrlString)
        print("makeRequestMovieList=====================",urlStr)
        guard let finalUrl = url else { return }
        let urlRequest = URLRequest(url: finalUrl)
        let dataTask = session.dataTask(with: urlRequest) { (data, response, error) in
            guard let data = data, error == nil else {
                
                return
            }
           
            self.parseMovieList(jsonData:data){ movie in
               
                DispatchQueue.main.async {
                    
                    completion(movie)
                }
            }
            
            
        }
        dataTask.resume()
        
    }
    
    func parseDetail(jsonData:Data,completion:@escaping((MovieDetail) -> ())){
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        guard let detailObj  = try? decoder.decode(MovieDetail.self, from: jsonData) else { return  }
        completion(detailObj)
        
        
    }
    
    func  makeRequestDetail(urlStr:String,completion :@escaping (MovieDetail) -> ()){
        
        let urlString = urlStr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        print("urlStr11=====================",urlStr)
        guard let finalUrlString = urlString  else {return }
        let url = URL(string: finalUrlString)
        guard let finalUrl = url else { return }
        let urlRequest = URLRequest(url: finalUrl)
        let dataTask = session.dataTask(with: urlRequest) { (data, response, error) in
            
            guard let data = data, error == nil else {
                
                return
            }
            
            self.parseDetail(jsonData:data){ detail in
                
                DispatchQueue.main.async {
                    completion(detail)
                }
            }
            
            
        }
        dataTask.resume()
        
    }
   
}






