//
//  AppDelegate.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import UIKit
import Reachability
@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    let reachability = try! Reachability()
    var isNetworkReachable = true
    class func allowsAnyHTTPSCertificate(forHost host: String?) -> Bool {
        return true
    }
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        if #available(iOS 13.0, *) {
            // In iOS 13 setup is done in SceneDelegate
        } else {
            let window = UIWindow(frame: UIScreen.main.bounds)
            self.window = window
            
            // if (user != nil && userSelfIdent != nil){
            let mainstoryboard:UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let newViewcontroller:UIViewController = mainstoryboard.instantiateViewController(withIdentifier: "listing") as! ViewController
            let navController = UINavigationController(rootViewController: newViewcontroller)
            window.rootViewController = navController
            
            //  }
        }
        return true
    }

    // MARK: UISceneSession Lifecycle

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    @available(iOS 13.0, *)
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
    func networkRechability(){
            reachability.whenReachable = { reachability in
                if reachability.connection == .wifi {
                    print("Reachable via WiFi")
                    self.isNetworkReachable = true
                } else {
                    print("Reachable via Cellular")
                    self.isNetworkReachable = true
                }
            }
            reachability.whenUnreachable = { _ in
                print("Not reachable")
                self.isNetworkReachable = false
                
            }

            do {
                try reachability.startNotifier()
            } catch {
                print("Unable to start notifier")
            }
        }

}

