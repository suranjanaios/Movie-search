//
//  GlobalConstant.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import Foundation
import UIKit
import Foundation
struct GlobalConstant {
    static  func getDynamicUrl()->(String){
       
    let movieListUrl = "http://www.omdbapi.com/?apikey=b9bd48a6&s="
        return movieListUrl
    }
    
    
    
    static let movieDetailUrl = "http://www.omdbapi.com/?apikey=b9bd48a6&i="
   
}
