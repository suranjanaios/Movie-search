//
//  MovieDetailViewModel.swift
//  MovieSearch
//
//  Created by suranjana on 13/02/21.
//

import Foundation
import Reachability
@objc class MovieDetailViewModel : NSObject {
    var MovieViewModels : MovieDetail? = nil{
        didSet {
            self.bindToMovieDetail()
        }
    }
    private var token :NSKeyValueObservation?
    var bindToMovieDetail :(() -> ()) = {  }
    var showAlert :(() -> ()) = {  }
    var detailURl:String?
     init(url:String){
        super.init()
        detailURl = url
        self.getMovieDetail()
        
        
       
    }
    func getMovieDetail() {
        if let urlString = detailURl{
        webServiceManager.shared.makeRequestDetail(urlStr: urlString){ movieDetail in
            self.MovieViewModels = movieDetail
            
       }
    }
            
        
        
    }
}
