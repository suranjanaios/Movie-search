//
//  ListViewModel.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import Foundation
import Reachability
@objc class ListViewModel : NSObject {
   @objc dynamic var MovieViewModels : [MovieViewModel]? = [MovieViewModel]()
    private var token :NSKeyValueObservation?
    var bindToMovieList :(() -> ()) = {  }
    var showAlert :(() -> ()) = {  }
    var pageNo = 1
    override init(){
        super.init()
        token = self.observe(\.MovieViewModels) { _,_ in
            
            self.bindToMovieList()
            self.pageNo = self.pageNo + 1
        }
        
       
    }
    func getMovieList(searchString:String) {
        let urlString = GlobalConstant.getDynamicUrl()+searchString+"&type=movie&page="+String(pageNo)
        
        webServiceManager.shared.makeRequestMovieList(urlStr: urlString){[weak self] news in
            self?.MovieViewModels = news.compactMap(MovieViewModel.init)
            
        }
        
    }
}


class MovieViewModel : NSObject {
    var title : String
    var year :String?
    var imdbID : String?
    var movie_Type : String?
    var poster : String?
   
    
    init(title :String, year: String, imdbID: String, movie_Type:String, poster:String ) {
        self.title = title
        self.year = year
        self.imdbID = imdbID
        
        self.movie_Type = movie_Type
        self.poster = poster
        
    }
    
    init(movie :Movie) {
        
        self.title = movie.title
        self.year = movie.year
        self.imdbID = movie.imdbID
        
        self.movie_Type = movie.movieType
        self.poster = movie.poster
        
    }
}
