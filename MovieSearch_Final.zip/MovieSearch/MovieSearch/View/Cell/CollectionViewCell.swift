//
//  CollectionViewCell.swift
//  MovieSearch
//
//  Created by suranjana on 13/02/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var movieTitle: UILabel!
    
    @IBOutlet weak var movieImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
