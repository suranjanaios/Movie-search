//
//  MovieDetailViewController.swift
//  MovieSearch
//
//  Created by suranjana on 13/02/21.
//

import UIKit
import Reachability
import MBProgressHUD
class MovieDetailViewController: UIViewController {
    @IBOutlet weak var writerLblHeight: NSLayoutConstraint!
    
    @IBOutlet weak var descriptionLabelHeight: NSLayoutConstraint!
    @IBOutlet weak var popularityLbl: UILabel!
    @IBOutlet weak var reviewsLbl: UILabel!
    @IBOutlet weak var scoreLbl: UILabel!
    @IBOutlet weak var writerLbl: UILabel!
    @IBOutlet weak var authorLbl: UILabel!
    
    @IBOutlet weak var DirectorLbl: UILabel!
    
    @IBOutlet weak var categoryLbl: UILabel!
    
    @IBOutlet weak var ratingLbl: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    
    @IBOutlet weak var durationLbl: UILabel!
    @IBOutlet weak var contentView: UIView!
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var yearLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UITextView!
    var reachability: Reachability?
    var itemId:String?
    var movieDetailVMObj :MovieDetailViewModel?
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = "Movie Detail"
        //self.navigationController?.navigationBar.topItem?.title = " "
        self.populateUI()
    }
    
    
    
    // MARK: API call method
    func populateUI(){
        
        DispatchQueue.main.async {
            let loadingNotification = MBProgressHUD.showAdded(to: self.view, animated: true)
            loadingNotification.mode = MBProgressHUDMode.indeterminate
            loadingNotification.label.text = "Loading..."
        }
        
        if let movieID = self.itemId {
            self.appDelegate.networkRechability()
            if (self.appDelegate.isNetworkReachable){
                self.movieDetailVMObj = MovieDetailViewModel(url:GlobalConstant.movieDetailUrl+movieID)
            }else{
                self.showAlert(msg: "Please check your network connection.")
            }
            
        }
        
        // setting up the bindings
        self.movieDetailVMObj?.bindToMovieDetail = {
           
            self.showDetail()
            
            
        }
    }
    
    // MARK: Alert method
    func showAlert(msg:String){
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        let alert = UIAlertController(title: "Alert", message: msg, preferredStyle: UIAlertController.Style.alert)
        
        
        alert.addAction(UIAlertAction(title: "Ok",
                                      style: UIAlertAction.Style.default,
                                      handler: {(_: UIAlertAction!) in
                                        
                                      }))
        self.present(alert, animated: true, completion: nil)
    }
    
    // MARK: populate UI method
    func showDetail(){
      DispatchQueue.main.async {
           
        if let titleStr = self.movieDetailVMObj?.MovieViewModels?.Title {
            self.titleLabel.text = titleStr
        }
        
        if let yearStr = self.movieDetailVMObj?.MovieViewModels?.Year {
            self.yearLabel.text = yearStr
        }
        if let imageUrl = self.movieDetailVMObj?.MovieViewModels?.Poster {
            self.imgView?.sd_setImage(with: URL(string:imageUrl ) , placeholderImage: UIImage(named: "Image"))
        }
        if let descstr = self.movieDetailVMObj?.MovieViewModels?.Plot {
            self.descriptionLabel.text = descstr
            
        }
        var categoryString = ""
        if let catStr = self.movieDetailVMObj?.MovieViewModels?.Type {
            categoryString = catStr
            self.categoryLbl.text = categoryString
        }
        var timeStr = ""
        if let durationStr = self.movieDetailVMObj?.MovieViewModels?.Runtime {
            var hr = 0
            var min = 0
            let minStr = durationStr.components(separatedBy: " ")
            if let hour = Int(minStr[0]) {
                hr  =   hour  / 60
                min =   hour % 60
                
            }
            timeStr = String(hr)+" h "+String(min)+" m "
            self.durationLbl.text = timeStr
        }
        
        if let ratingStr = self.movieDetailVMObj?.MovieViewModels?.imdbRating {
            self.ratingLbl.text = ratingStr
            
        }
        
        if let scoreStr = self.movieDetailVMObj?.MovieViewModels?.imdbRating {
            self.scoreLbl.text = scoreStr
            
        }
        if let reviewStr = self.movieDetailVMObj?.MovieViewModels?.BoxOffice {
            self.reviewsLbl.text = reviewStr
            
        }
        if let popularityStr = self.movieDetailVMObj?.MovieViewModels?.imdbVotes {
            self.popularityLbl.text = popularityStr
            
        }
        if let dirStr = self.movieDetailVMObj?.MovieViewModels?.Director {
            self.DirectorLbl.text = dirStr
            
        }
        if let writerStr = self.movieDetailVMObj?.MovieViewModels?.Writer {
            self.writerLbl.text = writerStr
            
        }
        if let actorStr = self.movieDetailVMObj?.MovieViewModels?.Actors {
            self.authorLbl.text = actorStr
            
        }
        
        self.setDynamicTextViewHeight()
       }
    }
    
    func setDynamicTextViewHeight(){
        print("NSThread.isMainThread()",Thread.isMainThread)
        let fixedWidthContent = descriptionLabel.frame.size.width
        let newSize = descriptionLabel.sizeThatFits(CGSize(width: fixedWidthContent, height: CGFloat.greatestFiniteMagnitude))
        descriptionLabelHeight.constant = newSize.height
        
        
        let fixedWidthContent1 = writerLbl.frame.size.width
        let newSize1 = writerLbl.sizeThatFits(CGSize(width: fixedWidthContent1, height: CGFloat.greatestFiniteMagnitude))
        writerLblHeight.constant = newSize1.height
        
        MBProgressHUD.hide(for: self.view, animated: true)
        
    }
}
