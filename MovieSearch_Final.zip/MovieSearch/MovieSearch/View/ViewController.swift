//
//  ViewController.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import UIKit
import SDWebImage
import MBProgressHUD
import Reachability
class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var movieListCollectionView: UICollectionView!
    
    @IBOutlet weak var noResultLbl: UILabel!
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    var listModelObj :ListViewModel?
    var allMovieListModels : [MovieViewModel]? = [MovieViewModel]()
    var footerView:CustomFooterView?
    let footerViewReuseIdentifier = "RefreshFooterView"
    var isLoading:Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "Movie Listing"
        self.listModelObj = ListViewModel()
        self.movieListCollectionView.register(UINib(nibName: "CustomFooterView", bundle: nil), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: footerViewReuseIdentifier)
        
    }
    func loadTable(){
        
        DispatchQueue.main.async {
            self.noResultLbl.isHidden = true
            self.movieListCollectionView.isHidden = false
            self.movieListCollectionView.delegate = self
            self.movieListCollectionView.dataSource = self
            self.movieListCollectionView.reloadData()
            MBProgressHUD.hide(for: self.view, animated: true)
        }
    }
    // MARK: API call method
    func populateTable(){
        
        DispatchQueue.main.async {
            let loadingNotification = MBProgressHUD.showAdded(to: self.view, animated: true)
            loadingNotification.mode = MBProgressHUDMode.indeterminate
            loadingNotification.label.text = "Searching..."
        }
        
        // setting up the bindings
        
        self.listModelObj?.bindToMovieList = {
            if let allModels = self.listModelObj?.MovieViewModels {
                if (allModels.count == 0){
                    self.showAlert(msg: "No data found.")
                    self.noResultLbl.isHidden = false
                }else{
                    self.allMovieListModels?.append(contentsOf: allModels)
                    self.loadTable()
                }
            }
        }
        
        
        
        
    }
    
    
    func showAlert(msg:String){
        DispatchQueue.main.async {
            MBProgressHUD.hide(for: self.view, animated: true)
        }
        let alert = UIAlertController(title: "Alert", message: msg,         preferredStyle: UIAlertController.Style.alert)
        
        
        alert.addAction(UIAlertAction(title: "Ok",
                                      style: UIAlertAction.Style.default,
                                      handler: {(_: UIAlertAction!) in
                                        //Sign out action
                                      }))
        self.present(alert, animated: true, completion: nil)
    }
}
// MARK: - UICollectionViewDataSource
extension ViewController{
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.allMovieListModels?.count ?? 1
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        // 1
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        // get a reference to our storyboard cell
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "identifier", for: indexPath as IndexPath) as! CollectionViewCell
        let movieObj = self.allMovieListModels?[indexPath.row]
        
        
        if let imageUrl = movieObj?.poster {
            cell.movieImg?.sd_setImage(with: URL(string:imageUrl ) , placeholderImage: UIImage(named: "Image"))
        }
        
        if let titleString = movieObj?.title {
            cell.movieTitle.text = titleString
        }
        
        return cell
    }
    
    // MARK: - UICollectionViewDelegate
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc : MovieDetailViewController = storyboard.instantiateViewController(withIdentifier: "detailView") as! MovieDetailViewController
        vc.itemId = self.allMovieListModels?[indexPath.item].imdbID
        self.navigationController?.pushViewController(vc, animated: true)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        print((collectionView.frame.size.width)/2)
        return CGSize(width: (collectionView.bounds.size.width-1)/2, height: 150)
        
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if isLoading {
            return CGSize.zero
        }
        return CGSize(width: collectionView.bounds.size.width, height: 55)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionFooter {
            let aFooterView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: footerViewReuseIdentifier, for: indexPath) as! CustomFooterView
            self.footerView = aFooterView
            self.footerView?.backgroundColor = UIColor.clear
            return aFooterView
        } else {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: footerViewReuseIdentifier, for: indexPath)
            return headerView
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplaySupplementaryView view: UICollectionReusableView, forElementKind elementKind: String, at indexPath: IndexPath) {
        if elementKind == UICollectionView.elementKindSectionFooter {
            self.footerView?.prepareInitialAnimation()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplayingSupplementaryView view: UICollectionReusableView, forElementOfKind elementKind: String, at indexPath: IndexPath) {
        if elementKind == UICollectionView.elementKindSectionFooter {
            self.footerView?.stopAnimate()
        }
    }
    
    
    //compute the scroll value and play witht the threshold to get desired effect
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let threshold   = 100.0 ;
        let contentOffset = scrollView.contentOffset.y;
        let contentHeight = scrollView.contentSize.height;
        let diffHeight = contentHeight - contentOffset;
        let frameHeight = scrollView.bounds.size.height;
        var triggerThreshold  = Float((diffHeight - frameHeight))/Float(threshold);
        triggerThreshold   =  min(triggerThreshold, 0.0)
        let pullRatio  = min(abs(triggerThreshold),1.0);
        self.footerView?.setTransform(inTransform: CGAffineTransform.identity, scaleFactor: CGFloat(pullRatio))
        if pullRatio >= 1 {
            self.footerView?.animateFinal()
        }
        print("pullRation:\(pullRatio)")
    }
    //compute the offset and call the load method
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let contentOffset = scrollView.contentOffset.y;
        let contentHeight = scrollView.contentSize.height;
        let diffHeight = contentHeight - contentOffset;
        let frameHeight = scrollView.bounds.size.height;
        let pullHeight  = abs(diffHeight - frameHeight);
        print("pullHeight:\(pullHeight)");
        if pullHeight == 0.0
        {
            guard let footerView = self.footerView, footerView.isAnimatingFinal else { return }
            print("load more trigger")
            self.isLoading = true
            self.footerView?.startAnimate()
            if let searchString = searchBar.text{
                self.appDelegate.networkRechability()
                if (self.appDelegate.isNetworkReachable == true){
                  listModelObj?.getMovieList(searchString: searchString )
                }else{
                  self.showAlert(msg: "Please check your network connection.")
                }
            }
            
        }
    }
}

extension ViewController:UISearchBarDelegate{
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        if let searchString = searchBar.text{
            if(searchString != ""){
                self.appDelegate.networkRechability()
                if (self.appDelegate.isNetworkReachable == true ){
                    listModelObj?.getMovieList(searchString: searchString )
                    self.populateTable()
                }else{
                    self.showAlert(msg: "Please check your network connection.")
                }
                
            }
        }
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            if (self.allMovieListModels?.count != 0){
                DispatchQueue.main.async {
                    self.allMovieListModels?.removeAll()
                    self.movieListCollectionView.reloadData()
                    self.listModelObj?.pageNo = 1
                }
            }
            self.movieListCollectionView.isHidden = true
        }
        
    }
    
    
}
