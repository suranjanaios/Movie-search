//
//  MovieList.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import Foundation
struct MovieList : Codable{
    
    var Response : String?
    var totalResults : String?
    var Search : [Movie] = [Movie]()
    
    
}
