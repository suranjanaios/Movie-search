//
//  Movie.swift
//  MovieSearch
//
//  Created by suranjana on 12/02/21.
//

import Foundation
struct  Movie : Codable {
    

    
    var title : String
    var year :String?
    var imdbID : String?
    var movieType : String?
    var poster : String?
    private enum rootKeys : String , CodingKey{

        case Title
        case Year
        case imdbID
        case `Type`
        case Poster
       
    }
   
   
    // MARK: Coding Keys

     init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: rootKeys.self)
        
       

        if let authorStr = try container.decodeIfPresent(String.self, forKey: .Title){
            title = authorStr
            
        } else {
            title = "NA"
        }
        
        if let titleStr = try container.decodeIfPresent(String.self, forKey: .Year){
            year = titleStr
            
        } else {
            year = "NA"
        }
        
        if let descriptionStr = try container.decodeIfPresent(String.self, forKey: .imdbID){
            imdbID = descriptionStr
            
        } else {
            imdbID = "NA"
        }
        if let descriptionStr = try container.decodeIfPresent(String.self, forKey: .Type){
            movieType = descriptionStr
            
        } else {
            movieType = "NA"
        }
        if let urlStr = try container.decodeIfPresent(String.self, forKey: .Poster){
            poster = urlStr
            
        } else {
            poster = "NA"
        }
        
        
        
    }
    
}
struct Search : Codable {
    let results: [Movie]
}

