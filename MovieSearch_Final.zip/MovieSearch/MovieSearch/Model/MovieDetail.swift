//
//  MovieDetail.swift
//  MovieSearch
//
//  Created by suranjana on 13/02/21.
//

import Foundation

struct  MovieDetail : Codable {
    
    var Title : String?
    var BoxOffice :String?
    var `Type` : String?
    var Poster : String?
    
    var Year : String?
    var Genre :String?
    var Runtime : String?
    var Director : String?
    var Writer : String?
    
    var Actors : String
    var Plot :String?
    var Language : String?
    var Country : String?
    var Awards : String?
    var imdbRating : String?
    var imdbVotes : String?
    
    //var Ratings : [[String:String]]?
    private enum rootKeys : String , CodingKey{
        case Poster
        case Title
        case `Type`
        case Year
        case Genre
        case Runtime
        case Director
        case Writer
        
        case Actors
        case Plot
        case Language
        case Country
        case Awards
        case imdbRating
        case BoxOffice
        case imdbVotes
        
    }
   
   
    // MARK: Coding Keys
   
     init(from decoder: Decoder) throws {
        
        let container = try decoder.container(keyedBy: rootKeys.self)
        
        if let titleStr = try container.decodeIfPresent(String.self, forKey: .Title){
            Title = titleStr
            
        } else {
            Title = "NA"
        }
        if let typeStr = try container.decodeIfPresent(String.self, forKey: .`Type`){
            `Type` = typeStr
            
        } else {
            `Type` = "NA"
        }

        if let releasedStr = try container.decodeIfPresent(String.self, forKey: .Year){
            Year = releasedStr
            
        } else {
            Year = "NA"
        }
        
        if let genreStr = try container.decodeIfPresent(String.self, forKey: .Genre){
            Genre = genreStr
            
        } else {
            Genre = "NA"
        }
        
        if let runtimeStr = try container.decodeIfPresent(String.self, forKey: .Runtime){
            Runtime = runtimeStr
            
        } else {
            Runtime = "NA"
        }
        if let directorStr = try container.decodeIfPresent(String.self, forKey: .Director){
            Director = directorStr
            
        } else {
            Director = "NA"
        }
        if let writerStr = try container.decodeIfPresent(String.self, forKey: .Writer){
            Writer = writerStr
            
        } else {
            Writer = "NA"
        }
        /////////////
        if let actorsStr = try container.decodeIfPresent(String.self, forKey: .Actors){
            Actors = actorsStr
            
        } else {
            Actors = "NA"
        }
        
        if let plotStr = try container.decodeIfPresent(String.self, forKey: .Plot){
            Plot = plotStr
            
        } else {
            Plot = "NA"
        }
        
        if let languageStr = try container.decodeIfPresent(String.self, forKey: .Language){
            Language = languageStr
            
        } else {
            Language = "NA"
        }
        if let countryStr = try container.decodeIfPresent(String.self, forKey: .Country){
            Country = countryStr
            
        } else {
            Country = "NA"
        }
        if let awardsStr = try container.decodeIfPresent(String.self, forKey: .Awards){
            Awards = awardsStr
            
        } else {
            Awards = "NA"
        }
        if let imdbRatingsStr = try container.decodeIfPresent(String.self, forKey: .imdbRating){
            imdbRating = imdbRatingsStr
            
        } else {
            imdbRating = "NA"
        }
        if let urlStr = try container.decodeIfPresent(String.self, forKey: .Poster){
            Poster = urlStr
            
        } else {
            Poster = "NA"
        }
        if let popularityStr = try container.decodeIfPresent(String.self, forKey: .BoxOffice){
            BoxOffice = popularityStr
            
        } else {
            BoxOffice = "NA"
        }

        if let votesStr = try container.decodeIfPresent(String.self, forKey: .imdbVotes){
            imdbVotes = votesStr
            
        } else {
            imdbVotes = "NA"
        }
        
        
    }
    
}
